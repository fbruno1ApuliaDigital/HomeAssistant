import sqlite3

# Connessione al database esistente
conn = sqlite3.connect('database.db')

# Creazione di un cursore
cursor = conn.cursor()

# Creazione della tabella per i log della caldaia domotica
cursor.execute('''
CREATE TABLE IF NOT EXISTS logs_caldaia (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    temperatura REAL,
    stato TEXT,  -- 'accesa', 'spenta', 'standby'
    consumo REAL,  -- consumo energetico in kWh
    pressione REAL  -- pressione in bar
)
''')

# Inserimento di alcuni log di esempio
cursor.execute("INSERT INTO logs_caldaia (temperatura, stato, consumo, pressione) VALUES (?, ?, ?, ?)", (75.5, 'accesa', 2.3, 1.2))
cursor.execute("INSERT INTO logs_caldaia (temperatura, stato, consumo, pressione) VALUES (?, ?, ?, ?)", (22.0, 'spenta', 0.0, 1.1))
cursor.execute("INSERT INTO logs_caldaia (temperatura, stato, consumo, pressione) VALUES (?, ?, ?, ?)", (60.0, 'standby', 0.5, 1.3))

# Salvataggio delle modifiche
conn.commit()

# Chiusura della connessione
conn.close()

print("Tabella per i log della caldaia aggiunta con successo!")