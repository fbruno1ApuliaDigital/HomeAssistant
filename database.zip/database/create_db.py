import sqlite3

# Connessione al database (crea il file se non esiste)
conn = sqlite3.connect('database.db')

# Creazione di un cursore
cursor = conn.cursor()

# Creazione di una tabella di esempio
cursor.execute('''
CREATE TABLE IF NOT EXISTS utenti (
    id INTEGER PRIMARY KEY,
    nome TEXT NOT NULL,
    email TEXT NOT NULL
)
''')

# Inserimento di alcuni dati di esempio
cursor.execute("INSERT INTO utenti (nome, email) VALUES (?, ?)", ('Mario Rossi', 'mario@example.com'))
cursor.execute("INSERT INTO utenti (nome, email) VALUES (?, ?)", ('Luca Bianchi', 'luca@example.com'))

# Salvataggio delle modifiche
conn.commit()

# Chiusura della connessione
conn.close()

print("Database creato con successo!")